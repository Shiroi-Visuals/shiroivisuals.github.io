# Legacy clouds on Minecraft 1.21.1 (Sodium + Iris)

## What this fixes

Minecraft 1.21.1 with Sodium can render vanilla clouds through Sodium's own cloud renderer. Iris may skip that renderer while shaders are active, so the shaderpack's `gbuffers_clouds` pass receives no clouds. This is a renderer compatibility issue; shader source alone cannot restore geometry that is never submitted to the shader pipeline.

This shaderpack already has a `gbuffers_clouds` pass. Once vanilla cloud rendering is routed through Iris, that pass applies the pack's existing cloud lighting, weather tint, fog, cloud shadows, and sky-object occlusion.

## Enable the compatibility workaround

1. Close Minecraft.
2. Open the instance's `config` folder.
3. Open `sodium-mixins.properties`. Create it if it does not exist.
4. Add the following line. If the file already contains other settings, append this line without removing them:

   `mixin.features.render.world.clouds=false`

5. Save the file and launch the instance again.

This disables Sodium's cloud-renderer mixin so vanilla clouds can pass through Iris and use this shaderpack's `gbuffers_clouds` effects. It does not change the shader's visual settings or cloud quality.

The line is also supplied in `sodium-mixins.properties` in this folder for copying. Do not replace an existing config file wholesale; merge the one setting into it.

## Limitations

This workaround changes the Sodium configuration for the whole instance, not only for this shaderpack. This ZIP has been validated on Minecraft 26.3 / Iris 1.11.7. The 1.21.1 Sodium/Iris behavior is based on the documented renderer workaround; this exact legacy setup was not available for an in-game visual test during this build.
