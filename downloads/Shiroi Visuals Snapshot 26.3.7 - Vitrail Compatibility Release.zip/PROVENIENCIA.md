# Procedência

De onde vem cada parte do Shiroi Visuals. O pack foi feito para se parecer com o Vibrant Visuals (VV) do Minecraft
Bedrock, da Mojang. Durante o desenvolvimento, o renderer do VV e os dados de configuração do jogo foram estudados
para entender como o visual é construído. Este arquivo diz o que veio desse estudo e de que forma.

Isto não é parecer jurídico. O que está descrito aqui reduz a dependência do material da Mojang, mas não garante
risco zero; quem publica deve avaliar por conta própria.

## Código (`shaders/`)

Escrito do zero (versão 9, reescrita completa), a partir de uma descrição do que cada etapa faz e de técnicas
publicadas, citadas no cabeçalho de cada arquivo. Nenhum shader do VV está no pack, nem traduzido linha a linha.
O único código de terceiros é o ajuste ACES (licença MIT, `THIRD_PARTY_NOTICES.md`).

## Dados de aparência (`shaders/lib/look.glsl`, parte do `shaders.properties`)

Os números que definem o visual foram medidos dos dados de configuração do VV (iluminação, atmosfera, névoa, água,
color grading por bioma, flash do End, névoa de powder snow), não de imagens:

- as curvas do dia (luz e cor do sol e da lua, cores do céu, força do espalhamento, halo) foram reamostradas numa
  grade própria, um ponto a cada 15 minutos de jogo, e arredondadas; os pontos de tempo e os valores originais não
  estão no pack. A imagem muda no máximo 4/255 em relação às curvas originais;
- os demais parâmetros (densidades de névoa, cores de névoa, temperaturas de cor, coeficientes da água etc.) estão
  como foram medidos. São parâmetros numéricos, não código nem imagem;
- não vêm do VV, foram ajustados aqui: a névoa da neve e da nevasca, a exposição com a câmera na água e no powder
  snow, a restrição do grading de bioma ao sol baixo, e a correção da chuva (o céu nublado continua iluminado).

## Texturas (`shaders/textures/`)

Todas foram geradas para o pack; nenhuma textura da Mojang está incluída:

- `caustics.png`: animação sintetizada (rede de células com bordas onduladas,
  falhas e brilhos ao longo das linhas), ajustada para ter as mesmas estatísticas das cáusticas do VV (espectro,
  distribuição de valores, velocidade). Nenhum pixel foi copiado: a maior correlação com a original, em qualquer
  deslocamento no espaço e no tempo, é 0,06 (uma cópia daria 1).
- `water_*`: relevo da água (normal map e rugosidade) sintetizado por fase aleatória a partir das estatísticas do
  relevo do VV (espectro, distribuição de alturas, ritmo). Correlação máxima com o original 0,26 (parada) e 0,44
  (corrente), a mesma faixa de duas sínteses independentes comparadas entre si (0,17 a 0,47).
- `brdf_lut.png`: a tabela split-sum do BRDF [Karis 2013], calculada pela fórmula (GGX, Smith-Schlick).
- A textura das nuvens é lida do próprio jogo em tempo de execução (`minecraft:textures/environment/clouds.png`);
  não está no pack.

## Material por bloco (`shaders/lib/surface.glsl`, `block.properties`)

Sem resource pack, metal, gemas, obsidiana, gelo e minérios recebem rugosidade e metal texel a texel por retas no
brilho do texel. As inclinações e faixas dessas retas foram medidas dos texture sets do VV (poucos coeficientes por
família de bloco). As texturas do VV não estão no pack.

## O que não faz parte da publicação

- O resource pack "Shiroi VV PBR", feito a partir das texturas de material do VV: não deve ser distribuído.
- As ferramentas de desenvolvimento (decodificador de materiais, simulador, geradores) e o histórico interno.
