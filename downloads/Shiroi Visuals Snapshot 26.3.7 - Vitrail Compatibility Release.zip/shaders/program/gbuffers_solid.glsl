// Opaque geometry: terrain, block entities, entities and the held item write the G-buffer (layout in
// lib/gbuffer.glsl). Terrain is lit later by deferred; the others are also lit here, see GBUF_FORWARD.
#include "/lib/common.glsl"
#include "/lib/gbuffer.glsl"

#ifdef VERTEX_SHADER
in vec4 mc_Entity;
in vec4 mc_midTexCoord;
uniform int blockEntityId;
uniform int entityId;
out vec2 vUv;
out vec2 vLm;
out vec4 vColor;
out vec3 vNormal;
out vec3 vPlayerPos;
flat out vec2 vMidUv;
flat out vec2 vHalfUv;
flat out int vMat;
void main() {
    vUv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    vLm = normalizeLightmap((gl_TextureMatrix[1] * gl_MultiTexCoord1).xy);
    vColor = gl_Color;
    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vPlayerPos = (gbufferModelViewInverse * viewPos).xyz;
    vNormal = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal));
    vMidUv = mc_midTexCoord.xy;
    vHalfUv = abs(vUv - mc_midTexCoord.xy);   // half size of the sprite in the atlas
    #if defined GBUF_TERRAIN
        vMat = int(mc_Entity.x + 0.5);
    #elif defined GBUF_BLOCK
        vMat = blockEntityId;
    #elif defined GBUF_HAND
        vMat = MAT_HAND;
    #else
        vMat = MAT_ENTITY;
    #endif
    gl_Position = taaJitterClip(gl_ProjectionMatrix * viewPos);
}
#endif

#ifdef FRAGMENT_SHADER
#include "/lib/surface.glsl"
#ifndef GBUF_TERRAIN
    // MC 26 batches entity drawing and Iris does not promise it happens before deferred; what is drawn after it would
    // never be lit from the G-buffer (players and mobs went missing). So these are lit right here and flagged
    // SURFACE_FORWARD, and deferred keeps their colour in either order.
    #define GBUF_FORWARD
    #include "/lib/shading.glsl"
#endif
uniform sampler2D gtexture;
uniform sampler2D specular;   // Iris PBR atlases (the texture sets of the resource pack)
uniform sampler2D normals;
uniform vec4 entityColor;
uniform float alphaTestRef;
in vec2 vUv;
in vec2 vLm;
in vec4 vColor;
in vec3 vNormal;
in vec3 vPlayerPos;
flat in vec2 vMidUv;
flat in vec2 vHalfUv;
flat in int vMat;

// outputs are declared and first written in location order (Vitrail numbers them by first write)
layout(location = 0) out vec4 outAlbedo;
layout(location = 1) out vec4 outNormal;
layout(location = 2) out vec4 outLight;
#ifdef GBUF_FORWARD
/* RENDERTARGETS: 1,2,3,0,7,5 */
layout(location = 3) out vec4 outColor;
// colortex7: rgb 0 (glint drawn afterwards adds to it), a = 2 + view depth. MC 26 draws translucent entity parts
// (player skins are entityTranslucent) after the deferred pass and after Iris copies depthtex1, so composite had no
// depth for them: against the sky they took the whole fog volume, under water the extinction down to the floor.
// Deferred overwrites colortex7 everywhere, so this depth survives only for what is drawn after it.
layout(location = 4) out vec4 outLateDepth;
// colortex5: the entity's direct light (what deferred writes to colortex7 for the G-buffer); composite3 moves it to
// colortex7 for the caustics under water. An entity pixel never shows the sun or moon that colortex5 otherwise holds.
layout(location = 5) out vec4 outDirect;
#else
/* RENDERTARGETS: 1,2,3 */
#endif

// blocks that get the relief from their own texture when the resource pack gives them no normal map
bool takesTexelRelief(int mat) {
    return mat != MAT_LAVA && mat != MAT_NETHER_PORTAL && mat != MAT_LEAVES && mat != MAT_FOLIAGE && vHalfUv.x > 0.0 && vHalfUv.y > 0.0;
}

void main() {
    vec4 tex = texture(gtexture, vUv);
    if (tex.a < max(alphaTestRef, 0.1)) discard;
    vec3 albedo = tex.rgb * vColor.rgb;   // texture x vertex tint (biome colours)
    #if defined GBUF_ENTITIES || defined GBUF_HAND
        albedo = mix(albedo, entityColor.rgb, entityColor.a);   // hurt / explosion flash
    #endif
    Material m = blockMaterial(vMat, tex.rgb);
    // metal / gem blocks, obsidian and ores: the material texel by texel (lib/surface.glsl texelDetailMaterial)
    #if defined PBR_TABLE && defined GBUF_TERRAIN
        bool texelDetail = vMat == MAT_ORE || vMat == MAT_ORE_GEM || vMat == MAT_METAL || vMat == MAT_GEM || vMat == MAT_OBSIDIAN || vMat == MAT_ICE;
        if (texelDetail && vHalfUv.x > 0.0 && vHalfUv.y > 0.0) texelDetailMaterial(m, vMat, tex.rgb, spriteMeanLumSat(gtexture, vMidUv, vHalfUv));
    #endif
    vec3 tsNormal = vec3(0.0, 0.0, 1.0);
    bool hasTextureSet = false;
    #ifndef GBUF_HAND
        hasTextureSet = textureSetMaterial(specular, normals, vUv, m, tsNormal);
    #endif

    vec3 geoNormal = gl_FrontFacing ? normalize(vNormal) : -normalize(vNormal);
    vec3 N = geoNormal;
    bool normalMapped = hasTextureSet && tsNormal.z < 0.9999;
    if (normalMapped) N = normalize(derivativeFrame(geoNormal, vPlayerPos, vUv) * tsNormal);
    #if defined MICRO_DETAIL && defined GBUF_TERRAIN
        else if (takesTexelRelief(vMat))
            N = normalize(derivativeFrame(geoNormal, vPlayerPos, vUv) * texelRelief(gtexture, vUv, vMidUv, vHalfUv));
    #endif

    outAlbedo = encodeAlbedo(albedo, m.metal, m.sss);
    outNormal = encodeNormals(N, geoNormal, m.roughness, m.emissive);
    outLight = encodeLighting(vLm, vMat, SURFACE_DEFERRED);

    #ifdef GBUF_FORWARD
        bool hand = vMat == MAT_HAND;
        Surface s;
        s.albedo = srgbToLinear(albedo);
        s.metal = m.metal;
        s.sss = m.sss;
        s.roughness = m.roughness;
        s.emissive = m.emissive;
        s.blockLevel = vLm.x;
        s.skyLevel = vLm.y;
        s.normal = N;
        s.flatNormal = geoNormal;
        s.pos = vPlayerPos;
        s.viewDepth = hand ? 0.0 : -(gbufferModelView * vec4(vPlayerPos, 1.0)).z;
        float dist = length(vPlayerPos);
        vec3 V = vPlayerPos / max(dist, 1e-4);
        // under water the caustics fall on mobs and players as on the terrain
        float caustics = submergedCaustics(vPlayerPos + cameraPosition, N);
        float fogT;
        KeyLightResult key;
        vec3 col = shadeSurface(s, daylight(), V, dist, skyIrradianceNow(), vec4(0.0), caustics, fogT, key);
        outLight.w = SURFACE_FORWARD;
        // after deferred colortex2 is the bloom glow weight, and deferred skips it for forward pixels: write no normal
        // here, or entities drawn after deferred would glow by their normal's x
        outNormal = vec4(0.0, 0.0, 0.0, 1.0);
        outColor = vec4(sanitize(col), tex.a);
        outLateDepth = vec4(0.0, 0.0, 0.0, hand ? 0.0 : 2.0 + s.viewDepth);
        outDirect = vec4((key.diffuse + key.specular) * (1.0 - fogT) / max(caustics, 1e-3), 0.0);
    #endif
}
#endif
