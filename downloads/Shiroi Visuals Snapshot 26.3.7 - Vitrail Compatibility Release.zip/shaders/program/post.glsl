// HDR post chain:
//  LE_DOWN      1/8 resolution gaussian of log luminance (colortex15): the coarse "base" layer of local exposure
//  LE_APPLY     optional TAA, then local exposure: base / detail decomposition [Durand & Dorsey 2002] where the
//               base is the bilateral grid [Chen et al. 2007] mixed with the gaussian; the base is pulled towards the
//               average luminance by LOCAL_EXPOSURE_STRENGTH, the detail is kept. Also stores the frame for next
//               frame's reflections (colortex6).
//  BLOOM_DOWN   dual filter downsample [Bjorge 2015, "Bandwidth-Efficient Rendering"]: centre 1/2 + four diagonal
//               taps 1/8; the first level carries the emissive share of the luminance in alpha
//  BLOOM_UP     dual filter upsample: eight diagonal taps (1/6 at 2 texels, 1/12 at 4 texels) of the level below,
//               plus the emissive share of this level (tight glow of light sources)
//  BLOOM_BLEND  last upsample added to the frame
#include "/lib/common.glsl"

#ifdef VERTEX_SHADER
void main() { gl_Position = ftransform(); }
#endif

#ifdef FRAGMENT_SHADER
#include "/lib/exposure.glsl"
uniform sampler2D colortex0;
uniform sampler2D colortex2;   // after deferred: emissive glow weight
uniform sampler2D colortex8;
uniform sampler2D colortex9;
uniform sampler2D colortex10;
uniform sampler2D colortex11;
uniform sampler2D colortex12;
uniform sampler2D colortex13;
uniform sampler2D colortex15;
uniform sampler3D gridImgSampler;

vec2 screenSize() { return vec2(viewWidth, viewHeight); }
float logRangeNorm(float lumLog) { return (lumLog - LUM_RANGE.x) / (LUM_RANGE.y - LUM_RANGE.x); }

#ifdef LE_DOWN
/* RENDERTARGETS: 15 */
layout(location = 0) out vec4 outLog;
void main() {
    vec2 uv = gl_FragCoord.xy / max(floor(screenSize() * 0.125), vec2(1.0));
    const int R = 2;                 // 5x5 taps, 4 pixels apart
    float sigma2 = float(R * R) * 0.5;
    float sum = 0.0, weight = 0.0;
    for (int y = -R; y <= R; y++) for (int x = -R; x <= R; x++) {
        vec2 o = vec2(x, y);
        float w = exp(-dot(o, o) / sigma2);
        vec2 p = min(uv + o * 4.0 / screenSize(), vec2(1.0) - 0.5 / screenSize());
        sum += w * log2(clamp(luminance(texture(colortex0, p).rgb), LUM_RANGE.z, LUM_RANGE.w));
        weight += w;
    }
    outLog = vec4(sum / weight, 0.0, 0.0, 1.0);
}
#endif

#ifdef LE_APPLY
uniform sampler2D colortex6;
uniform sampler2D colortex3;   // z: material id (MAT_OUTLINE under the block outline)
uniform sampler2D depthtex0;
/* RENDERTARGETS: 0,6 */
layout(location = 0) out vec4 outColor;
layout(location = 1) out vec4 outPrev;

// trilinear read of the filtered bilateral grid: x = weight, y = weighted normalised log luminance
vec2 gridLookup(vec3 p) {
    vec3 q = p * vec3(GRID_DIM) - 0.5;
    ivec3 i0 = ivec3(floor(q));
    vec3 f = q - vec3(i0);
    vec2 r = vec2(0.0);
    for (int k = 0; k < 8; k++) {
        ivec3 o = ivec3(k & 1, (k >> 1) & 1, k >> 2);
        vec3 w = mix(1.0 - f, f, vec3(o));
        r += texelFetch(gridImgSampler, clamp(i0 + o, ivec3(0), GRID_DIM - 1), 0).xy * (w.x * w.y * w.z);
    }
    return r;
}

vec3 toYCoCg(vec3 c) { return vec3(0.25 * c.r + 0.5 * c.g + 0.25 * c.b, 0.5 * c.r - 0.5 * c.b, -0.25 * c.r + 0.5 * c.g - 0.25 * c.b); }
vec3 fromYCoCg(vec3 c) { return vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z); }

// Catmull-Rom (tension 0.5) on the 4x4 texels around p, with weights per axis
//   w0 = f(-1/2 + f(1 - f/2)), w1 = 1 + f^2(-5/2 + 3f/2), w2 = f(1/2 + f(2 - 3f/2)), w3 = f^2(-1/2 + f/2).
// The middle pair is merged into one bilinear tap at (w2 / (w1 + w2)); dropping the four corner taps (their
// weight products are tiny) leaves five bilinear taps, renormalised by their total weight.
vec3 catmullRomHistory(vec2 uv) {
    vec2 res = screenSize();
    vec2 p = uv * res - 0.5;
    vec2 f = p - floor(p);
    vec2 centre = floor(p) + 0.5;
    vec2 w0 = f * (-0.5 + f * (1.0 - 0.5 * f));
    vec2 w1 = 1.0 + f * f * (-2.5 + 1.5 * f);
    vec2 w2 = f * (0.5 + f * (2.0 - 1.5 * f));
    vec2 w3 = f * f * (-0.5 + 0.5 * f);
    vec2 wMid = w1 + w2;
    vec2 tLo = (centre - 1.0) / res, tHi = (centre + 2.0) / res, tMid = (centre + w2 / wMid) / res;
    vec3 c = texture(colortex6, vec2(tMid.x, tLo.y)).rgb * (wMid.x * w0.y)
           + texture(colortex6, vec2(tLo.x, tMid.y)).rgb * (w0.x * wMid.y)
           + texture(colortex6, tMid).rgb * (wMid.x * wMid.y)
           + texture(colortex6, vec2(tHi.x, tMid.y)).rgb * (w3.x * wMid.y)
           + texture(colortex6, vec2(tMid.x, tHi.y)).rgb * (wMid.x * w3.y);
    float wSum = wMid.x * w0.y + w0.x * wMid.y + wMid.x * wMid.y + w3.x * wMid.y + wMid.x * w3.y;
    return max(c / wSum, 0.0);
}

// temporal anti-aliasing: reprojected history clipped to the neighbourhood (mean +- 1.25 sigma in YCoCg, on
// luminance-compressed colour against fireflies) [Karis 2014, "High Quality Temporal Supersampling"]
vec3 temporalResolve(vec2 uv, vec3 current) {
    ivec2 px = ivec2(gl_FragCoord.xy);
    float depth = texture(depthtex0, uv).r;
    vec2 prevUv = uv;
    if (depth >= 0.56) {   // the hand moves with the camera: no reprojection
        vec3 player = viewToPlayer(screenToView(uv, depth)) + cameraPosition - previousCameraPosition;
        vec4 clip = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(player, 1.0));
        prevUv = (clip.xy / clip.w) * 0.5 + 0.5;
    }
    if (any(lessThan(prevUv, vec2(0.0))) || any(greaterThan(prevUv, vec2(1.0)))) return current;
    vec3 mean = vec3(0.0), meanSq = vec3(0.0);
    for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) {
        vec3 c = sanitize(texelFetch(colortex0, clamp(px + ivec2(x, y), ivec2(0), ivec2(screenSize()) - 1), 0).rgb);
        c = toYCoCg(c / (1.0 + luminance(c)));
        mean += c; meanSq += c * c;
    }
    mean /= 9.0;
    vec3 sigma = sqrt(max(meanSq / 9.0 - mean * mean, 0.0));
    vec3 hist = sanitize(catmullRomHistory(prevUv));
    vec3 h = toYCoCg(hist / (1.0 + luminance(hist)));
    vec3 hi = mean + 1.25 * sigma;
    // clip the history towards the mean until it is inside the box
    vec3 d = h - mean;
    vec3 over = max(abs(d) / max(hi - mean, vec3(1e-5)), vec3(1.0));
    h = mean + d / max(over.x, max(over.y, over.z));
    vec3 c = toYCoCg(current / (1.0 + luminance(current)));
    float blend = TAA_BLEND * saturate(1.0 - length((prevUv - uv) * screenSize()) * 0.02);
    vec3 r = fromYCoCg(mix(c, h, blend));
    return r / max(1.0 - luminance(r), 1e-4);
}

void main() {
    vec2 uv = gl_FragCoord.xy / screenSize();
    vec3 col = sanitize(texture(colortex0, uv).rgb);
    #ifdef TAA
        // the block outline is a line 2 to 3 pixels wide drawn without jitter: with history it faded to a faint blur
        if (int(texture(colortex3, uv).z * 255.0 + 0.5) != MAT_OUTLINE) col = sanitize(temporalResolve(uv, col));
    #endif
    vec3 history = col;   // next frame's reflections and TAA read the colour before local exposure
    #ifdef LOCAL_EXPOSURE
        float lumLog = log2(clamp(luminance(col), LUM_RANGE.z, LUM_RANGE.w));
        vec2 g = gridLookup(vec3(uv, logRangeNorm(lumLog)));
        float gridLog = (g.y / max(g.x, 1e-6)) * (LUM_RANGE.y - LUM_RANGE.x) + LUM_RANGE.x;
        float blurLog = texture(colortex15, uv).r;
        float baseLog = g.x < 0.001 ? blurLog : mix(gridLog, blurLog, 0.5);
        float avgLog = log2(clamp(sceneAverageLuminance(), LUM_RANGE.z, LUM_RANGE.w));
        // base pulled towards the average, detail (lumLog - baseLog) kept as it is
        float targetLog = (lumLog - baseLog) + (1.0 - LOCAL_EXPOSURE_STRENGTH) * (baseLog - avgLog) + avgLog;
        col *= exp2(targetLog - lumLog);
    #endif
    // outputs written in location order (Vitrail numbers them by first write)
    outColor = vec4(col, 1.0);
    outPrev = vec4(history, 1.0);
}
#endif

#ifdef BLOOM_DOWN
layout(location = 0) out vec4 outBloom;
void main() {
    vec2 dstSize = max(floor(screenSize() * BLOOM_SCALE), vec2(1.0));
    vec2 srcSize = max(floor(screenSize() * BLOOM_SCALE * 2.0), vec2(1.0));
    vec2 uv = gl_FragCoord.xy / dstSize;
    vec2 h = 1.0 / srcSize;
    vec2 maxUv = (srcSize - 0.5) / srcSize;
    #ifdef BLOOM_FIRST
        // the HDR frame above the threshold; alpha: the part of its luminance that is emissive (colortex2.x after
        // deferred: emissive surfaces, eyes layers, lit particles)
        float threshold = sceneAverageLuminance() * BLOOM_THRESHOLD;
        #define TAP(o) { vec2 p = min(uv + (o), maxUv); vec3 c = texture(BLOOM_SRC, p).rgb; c *= step(threshold, luminance(c)); acc += vec4(c, luminance(c) * saturate(texture(colortex2, p).x)) * w; }
    #else
        #define TAP(o) { acc += texture(BLOOM_SRC, min(uv + (o), maxUv)) * w; }
    #endif
    vec4 acc = vec4(0.0);
    float w = 0.5;   TAP(vec2(0.0))
    w = 0.125;       TAP(vec2(h.x, h.y)) TAP(vec2(-h.x, -h.y)) TAP(vec2(-h.x, h.y)) TAP(vec2(h.x, -h.y))
    outBloom = acc;
}
#endif

// eight diagonal taps of a lower level: 1/6 at 2 texels, 1/12 at 4 texels (h = half a texel of that level)
vec3 dualUpsample(sampler2D src, vec2 uv, vec2 h, vec2 maxUv) {
    vec3 acc = vec3(0.0);
    acc += texture(src, min(uv + h * vec2(2.0, 2.0), maxUv)).rgb * 0.166;
    acc += texture(src, min(uv + h * vec2(-2.0, 2.0), maxUv)).rgb * 0.166;
    acc += texture(src, min(uv + h * vec2(2.0, -2.0), maxUv)).rgb * 0.166;
    acc += texture(src, min(uv + h * vec2(-2.0, -2.0), maxUv)).rgb * 0.166;
    acc += texture(src, min(uv + h * vec2(4.0, 4.0), maxUv)).rgb * 0.083;
    acc += texture(src, min(uv + h * vec2(-4.0, -4.0), maxUv)).rgb * 0.083;
    acc += texture(src, min(uv + h * vec2(-4.0, 4.0), maxUv)).rgb * 0.083;
    acc += texture(src, min(uv + h * vec2(4.0, -4.0), maxUv)).rgb * 0.083;
    return acc;
}

#ifdef BLOOM_UP
layout(location = 0) out vec4 outBloom;
void main() {
    vec2 dstSize = max(floor(screenSize() * BLOOM_SCALE), vec2(1.0));
    vec2 srcSize = max(floor(screenSize() * BLOOM_SCALE * 0.5), vec2(1.0));
    vec2 uv = gl_FragCoord.xy / dstSize;
    vec3 acc = dualUpsample(BLOOM_SRC, uv, 0.5 / srcSize, (srcSize - 0.5) / srcSize);
    #ifdef BLOOM_SELF
        // the emissive share of this level's own downsample (Iris flips the target, so this reads the down pass
        // result): light sources get a tight glow, everything else only the wide haze of the lower levels
        vec4 own = texture(BLOOM_SELF, uv);
        acc += own.rgb * saturate(own.a / max(luminance(own.rgb), 1e-6)) * EMISSIVE_BLOOM;
    #endif
    outBloom = vec4(acc, 0.0);
}
#endif

#ifdef BLOOM_BLEND
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;
void main() {
    vec2 uv = gl_FragCoord.xy / screenSize();
    vec2 srcSize = max(floor(screenSize() * 0.5), vec2(1.0));
    vec3 hdr = texture(colortex0, uv).rgb;
    #ifdef BLOOM
        hdr += dualUpsample(colortex8, uv, 0.5 / srcSize, (srcSize - 0.5) / srcSize) * BLOOM_INTENSITY;
    #endif
    outColor = vec4(hdr, 1.0);
}
#endif
#endif
