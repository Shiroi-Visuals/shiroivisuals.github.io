// Shadow pass: renders the cascades of lib/shadowmap.glsl into the tiles of the 2x2 shadow atlas.
//  * geometry-shader instancing: one invocation per cascade
//  * a triangle goes into cascade c only when it lies entirely inside that tile: nothing leaks into the
//    neighbouring tile, so the fragment shader needs no clipping and solid geometry keeps early depth testing
//  * triangles entirely inside the part served by the finer cascade are skipped in the coarser ones (receivers
//    read the shadow map straight along the light, so those texels would never be sampled)
//  * SHADOW_SINGLE_PASS (no geometry stage, see lib/common.glsl): the vertex stage projects straight into the one
//    cascade that fills the map, and the geometry stage only passes the triangle on, in the exact shape Vitrail folds
//    away (corners copied in a loop of three, nothing else)
#include "/lib/common.glsl"
#define SHADOWMAP_NO_SAMPLER
#define SHADOWMAP_NO_CLOUDS
#include "/lib/shadowmap.glsl"

#ifdef VERTEX_SHADER
in vec4 mc_Entity;
#ifdef SHADOW_SINGLE_PASS
out vec2 gTexcoord;
out vec4 gColor;
#else
out vec2 vTexcoord;
out vec4 vColor;
out vec3 vShadowPos;   // shadow model-view space
flat out int vSkip;
#endif
void main() {
    #ifdef SHADOW_SINGLE_PASS
        gTexcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
        gColor = gl_Color;
    #else
        vTexcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
        vColor = gl_Color;
    #endif
    bool water = int(mc_Entity.x + 0.5) == MAT_WATER;   // the water surface does not cast shadows
    #ifdef SHADOW_SINGLE_PASS
        vec3 clip = cascadeClip(shadowViewToGrid((gl_ModelViewMatrix * gl_Vertex).xyz), 0);
        // a water triangle has all three corners outside the clip volume and is dropped by the rasteriser
        gl_Position = water ? vec4(2.0, 2.0, 0.0, 1.0) : vec4(clip.xy, clamp(clip.z, -1.0, 1.0), 1.0);
    #else
        vShadowPos = shadowViewToGrid((gl_ModelViewMatrix * gl_Vertex).xyz);
        vSkip = water ? 1 : 0;
        gl_Position = vec4(0.0, 0.0, 0.0, 1.0);
    #endif
}
#endif

#ifdef GEOMETRY_SHADER
#ifdef SHADOW_SINGLE_PASS
layout(triangles) in;
layout(triangle_strip, max_vertices = 3) out;
in vec2 vTexcoord[];
in vec4 vColor[];
out vec2 gTexcoord;
out vec4 gColor;
void main() {
    for (int i = 0; i < 3; i++) {
        gl_Position = gl_in[i].gl_Position;
        gTexcoord = vTexcoord[i];
        gColor = vColor[i];
        EmitVertex();
    }
    EndPrimitive();
}
#else
#if SHADOW_QUALITY == 0
layout(triangles, invocations = 1) in;
#elif SHADOW_QUALITY == 1
layout(triangles, invocations = 3) in;
#else
layout(triangles, invocations = 4) in;
#endif
layout(triangle_strip, max_vertices = 3) out;
in vec2 vTexcoord[];
in vec4 vColor[];
in vec3 vShadowPos[];
flat in int vSkip[];
out vec2 gTexcoord;
out vec4 gColor;
void main() {
    if (vSkip[0] != 0) return;
    int c = gl_InvocationID;
    vec2 lo = min(vShadowPos[0].xy, min(vShadowPos[1].xy, vShadowPos[2].xy));
    vec2 hi = max(vShadowPos[0].xy, max(vShadowPos[1].xy, vShadowPos[2].xy));
    float extent = cascadeExtent(c);
    if (any(lessThan(lo, vec2(-extent))) || any(greaterThan(hi, vec2(extent)))) return;
    if (c > 0) {
        float skip = cascadeSkipExtent(c);
        if (all(greaterThan(lo, vec2(-skip))) && all(lessThan(hi, vec2(skip)))) return;
    }
    vec2 tile = cascadeTile(c);
    for (int k = 0; k < 3; k++) {
        vec3 clip = cascadeClip(vShadowPos[k], c);
        gTexcoord = vTexcoord[k];
        gColor = vColor[k];
        gl_Position = vec4(tile * 2.0 + clip.xy * 0.5 - 0.5, clamp(clip.z, -1.0, 1.0), 1.0);
        EmitVertex();
    }
    EndPrimitive();
}
#endif
#endif

#ifdef FRAGMENT_SHADER
#ifdef SHADOW_SOLID
void main() { }   // depth only
#else
uniform sampler2D gtexture;
in vec2 gTexcoord;
in vec4 gColor;
void main() {
    if (texture(gtexture, gTexcoord).a * gColor.a < 0.1) discard;   // cutout holes do not cast shadows
}
#endif
#endif
