#version 430 compatibility
#define BLOOM_DOWN
#define BLOOM_SRC colortex10
#define BLOOM_SCALE 0.0625
#define FRAGMENT_SHADER
/* RENDERTARGETS: 11 */
#include "/program/post.glsl"
