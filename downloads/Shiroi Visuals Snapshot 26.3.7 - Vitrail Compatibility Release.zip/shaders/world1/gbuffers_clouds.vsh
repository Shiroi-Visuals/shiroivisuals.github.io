#version 430 compatibility
#define DIM_END
#define VERTEX_SHADER
#include "/program/gbuffers_clouds.glsl"
