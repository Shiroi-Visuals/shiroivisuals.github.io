#version 430 compatibility
#define DIM_END
#define PREPARE_BASE
#define VERTEX_SHADER
#include "/program/prepare.glsl"
