#version 430 compatibility
#define DIM_NETHER
#define VERTEX_SHADER
#include "/program/deferred.glsl"
