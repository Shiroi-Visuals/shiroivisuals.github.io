#version 430 compatibility
#define DIM_NETHER
#define BLOOM_UP
#define BLOOM_SRC colortex13
#define BLOOM_SELF colortex12
#define BLOOM_SCALE 0.03125
#define VERTEX_SHADER
#include "/program/post.glsl"
