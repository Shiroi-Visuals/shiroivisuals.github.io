#version 430 compatibility
#define DIM_NETHER
#define FWD_WEATHER
#define VERTEX_SHADER
#include "/program/gbuffers_forward.glsl"
