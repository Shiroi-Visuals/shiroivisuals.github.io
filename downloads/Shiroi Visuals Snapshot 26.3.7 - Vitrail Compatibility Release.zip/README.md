# Shiroi Visuals Snapshot 26.3.7 — Vitrail Compatibility Release

Vulkan compatibility release of Shiroi Visuals for Minecraft 26.3. The shader-pack build targets Vitrail 0.13.0-beta+mc26.3; Vitrail itself is a beta renderer, and compatibility with other Vitrail or Minecraft versions has not been established.

## Compatibility

- Minecraft 26.3 with Fabric
- Vitrail 0.13.0-beta+mc26.3 and Sodium 0.9.2
- Vulkan-capable GPU supported by Vitrail

## Install

Place this ZIP in the instance's `shaderpacks` folder, select **Shiroi Visuals Snapshot 26.3.7 — Vitrail Compatibility Release** in Vitrail's shader picker, then reload the shader pack. The shader-pack files are at the ZIP root.

For Iris/OpenGL and the original multi-cascade shadow atlas, use the separate Iris Release ZIP.

## Shadows and known difference

Vitrail on this Minecraft version does not bind the pack's custom shadow geometry stages. This build therefore uses the pack's existing single-cascade shadow path while preserving its light-space transform, depth encoding, bias, filtering, transmission, water exclusion, and alpha cutout test. The leaf cutout is still present, but the single-cascade map has less distance-based detail; small openings between leaves can be less distinct, especially at a distance. Its shadows do not match the Iris build's multi-cascade result.

## Clouds

The pack's existing cloud rendering and cloud-grid effects are included. The Sodium setting documented in [LEGACY_CLOUDS_1.21.1.md](LEGACY_CLOUDS_1.21.1.md) applies to the legacy Minecraft 1.21.1 Iris + Sodium configuration, not to this Vitrail build.

## Credits

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for the ACES attribution and license, and [PROVENIENCIA.md](PROVENIENCIA.md) for the pack's source and asset notes.
