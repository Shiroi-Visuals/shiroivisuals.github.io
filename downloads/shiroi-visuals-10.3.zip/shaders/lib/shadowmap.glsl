#ifndef SHADOWMAP_GLSL
#define SHADOWMAP_GLSL
// Cascaded shadow maps [Engel 2006; Dimitrov 2007] in Iris' single shadow map.
//  * the shadow map is split into a 2x2 atlas, one cascade per tile; shadow.gsh renders each triangle into the
//    tiles that need it (see program/shadow.glsl)
//  * SHADOW_SINGLE_PASS (lib/common.glsl, engines without a geometry stage): one cascade over the whole map
//  * cascade c covers a light-space square of half size CASCADE_EXTENT[c] * SHADOW_RANGE around the camera
//  * receivers: normal offset + slope-scaled depth bias, box PCF of bilinear depth tests, transmission through thin
//    casters for subsurface materials
//  * pixel-art option (TEXEL_SHADOWS): every receiver is moved to the centre of its 1/16 block texel within the
//    surface plane and a single shadow-map texel is read, so each texture texel is either lit or not
//  * cloud shadows: the Java cloud cells projected along the light, box filtered
#include "/lib/common.glsl"
#include "/lib/look.glsl"

const float SHADOW_DEPTH_SPAN = 512.0;   // light-space depth covered by the atlas (+-256 m around the eye plane)
const float LIGHT_ANGLE_FLOOR = 0.2;     // N.L floor of the slope bias (keeps tan finite at grazing light)
// shadow.gsh keeps a triangle in a tile only when it lies entirely inside it, so casters up to one triangle size
// (a block face diagonal) from a tile edge can be missing: receivers stay this far inside
const float TILE_MARGIN = 1.5;
#ifdef SHADOW_SINGLE_PASS
    const float TILE_SIZE = 1.0;   // share of the map side taken by one cascade
#else
    const float TILE_SIZE = 0.5;
#endif

float cascadeExtent(int c) { return CASCADE_EXTENT[c] * SHADOW_RANGE; }
#ifdef SHADOW_SINGLE_PASS
    vec2 cascadeTile(int c) { return vec2(0.0); }
#else
    vec2 cascadeTile(int c) { return vec2(float(c & 1), float(c >> 1)) * 0.5; }
#endif
float cascadeTexel(int c) { return 2.0 / TILE_SIZE * cascadeExtent(c) / float(shadowMapResolution); }   // metres per map texel
int cascadeFilterTaps(int c, float scale) { return clamp(int(CASCADE_FILTER[c] * scale + 0.5), 1, 9); }

// Iris' shadow model-view space: camera centred, 100 m back along the light
vec3 shadowSpace(vec3 playerPos) { return (shadowModelView * vec4(playerPos, 1.0)).xyz; }
vec3 cascadeClip(vec3 ls, int c) { return vec3(ls.xy / cascadeExtent(c), -(ls.z + 100.0) / (SHADOW_DEPTH_SPAN * 0.5)); }

// receivers use cascade c while their shadow-space xy stays within this half size (filter footprint + tile margin)
float cascadeReceiverExtent(int c, float scale) {
    return cascadeExtent(c) - TILE_MARGIN - float(cascadeFilterTaps(c, scale) + 6) * cascadeTexel(c);
}
// casters entirely within this half size are only ever read from the finer cascade (minus the normal offset and the
// filter footprint), so shadow.gsh can skip them in cascade c
float cascadeSkipExtent(int c) {
    return cascadeReceiverExtent(c - 1, 1.0) - 0.5 - float(cascadeFilterTaps(c, 1.0) / 2 + 2) * cascadeTexel(c);
}

#ifndef SHADOWMAP_NO_SAMPLER
uniform sampler2D shadowtex0;

struct ShadowSample { float visibility; float transmission; int cascade; };

// textureGather order: x = (0,1), y = (1,1), z = (1,0), w = (0,0)
float gatherLerp(vec4 v, vec2 f) {
    vec2 rows = mix(v.wx, v.zy, f.x);
    return mix(rows.x, rows.y, f.y);
}
// light that crosses a caster: smooth falloff with the depth below the occluder
vec4 transmissionCurve(vec4 occluderDepth, float receiverDepth, float falloff) {
    vec4 x = saturate(falloff * (receiverDepth - occluderDepth));
    return 1.0 - x * x * (3.0 - 2.0 * x);
}
// weight of texel m (0..n) in an n x n box of bilinear taps one texel apart: inner texels 1, edges 1 - f and f
float boxTapWeight(int m, int n, float f) {
    return (m < n ? 1.0 - f : 0.0) + ((m > 0 && m <= n) ? f : 0.0);
}

// moves a receiver to the centre of its 1/16 block texel, keeping it in the surface plane
vec3 snapToTexelCentre(vec3 playerPos, vec3 normal) {
    const float T = 1.0 / 16.0;
    vec3 n = normalize(normal);
    vec3 toCentre = vec3(T * 0.5) - mod(playerPos + mod(cameraPosition, T), T);
    return playerPos + toCentre - n * dot(toCentre, n);
}

// normal: geometric normal used for the offset (vec3(0): no offset, e.g. volume samples)
ShadowSample shadowLookup(vec3 playerPos, vec3 normal, float filterScale, bool wantTransmission) {
    ShadowSample r = ShadowSample(1.0, 1.0, -1);
    bool hasNormal = dot(normal, normal) > 0.0;
    #ifdef TEXEL_SHADOWS
        if (hasNormal) playerPos = snapToTexelCentre(playerPos, normal);
    #endif
    vec3 toLight = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    float NdotL = hasNormal ? max(dot(normal, toLight), 0.0) : 1.0;
    vec3 ls0 = shadowSpace(playerPos);
    float res = float(shadowMapResolution);
    for (int c = 0; c < CASCADES; c++) {
        if (any(greaterThan(abs(ls0.xy), vec2(cascadeReceiverExtent(c, filterScale)))) || abs(cascadeClip(ls0, c).z) > 1.0) continue;
        // normal offset grows towards grazing light; 1.5 texels of the cascade keep coarse cascades from self-shadowing
        float texel = cascadeTexel(c);
        vec3 clip = cascadeClip(shadowSpace(playerPos + normal * (SHADOW_NORMAL_OFFSET + 1.5 * texel) * (1.0 - NdotL)), c);
        // slope-scaled bias: tan of the light angle, as a fraction of the cascade size, plus one texel of slope
        float ndl = min(max(NdotL, LIGHT_ANGLE_FLOOR), 1.0);
        float tanL = sqrt(1.0 - ndl * ndl) / ndl;
        float bias = (CASCADE_BIAS_SLOPE[c] * tanL + CASCADE_BIAS_CONST[c]) * (2.0 * cascadeExtent(c)) * SHADOW_BIAS_SCALE;
        bias += texel * 0.5 * min(tanL, 4.0) * SHADOW_BIAS_SCALE;
        float receiverDepth = clip.z * 0.5 + 0.5;
        float testDepth = receiverDepth - bias / SHADOW_DEPTH_SPAN;
        vec2 uv = cascadeTile(c) + (clip.xy * 0.5 + 0.5) * TILE_SIZE;
        float tapSpacing = (res * TILE_SIZE) / CASCADE_FILTER_RES[c];   // the filter keeps its world size at any resolution
        #ifdef TEXEL_SHADOWS
            int taps = 1;
        #else
            int taps = cascadeFilterTaps(c, filterScale);
        #endif
        int halfTaps = taps >> 1;
        float lit = 0.0, through = 0.0;
        float falloff = SHADOW_DEPTH_SPAN * SSS_FALLOFF;
        #ifndef TEXEL_SHADOWS
        if (tapSpacing == 1.0) {
            // the taps x taps bilinear box is a weighted sum over (taps + 1)^2 texels: one gather per 2x2 of them
            vec2 P = uv * res;
            vec2 cell = floor(P), f = P - cell;
            vec2 first = cell - float(halfTaps);
            int gathers = (taps + 2) >> 1;
            for (int gy = 0; gy < gathers; gy++) {
                vec2 wy = vec2(boxTapWeight(2 * gy, taps, f.y), boxTapWeight(2 * gy + 1, taps, f.y));
                for (int gx = 0; gx < gathers; gx++) {
                    vec2 wx = vec2(boxTapWeight(2 * gx, taps, f.x), boxTapWeight(2 * gx + 1, taps, f.x));
                    vec4 d = textureGather(shadowtex0, (first + vec2(float(2 * gx), float(2 * gy)) + 1.0) / res, 0);
                    vec4 W = vec4(wx.x * wy.y, wx.y * wy.y, wx.y * wy.x, wx.x * wy.x);
                    lit += dot(W, step(vec4(testDepth), d));
                    if (wantTransmission) through += dot(W, transmissionCurve(d, receiverDepth, falloff));
                }
            }
        } else
        #endif
        {
            vec2 lo = cascadeTile(c) + 0.5 / res, hi = cascadeTile(c) + TILE_SIZE - 0.5 / res;
            for (int j = 0; j < taps; j++) for (int i = 0; i < taps; i++) {
                vec2 p = clamp(uv + (vec2(float(i - halfTaps), float(j - halfTaps)) + 0.5) * tapSpacing / res, lo, hi);
                vec4 d = textureGather(shadowtex0, p, 0);
                vec2 f = fract(p * res + 0.5);
                #ifdef TEXEL_SHADOWS
                    lit += step(testDepth, d.w);
                #else
                    lit += gatherLerp(step(vec4(testDepth), d), f);
                #endif
                if (wantTransmission) through += gatherLerp(transmissionCurve(d, receiverDepth, falloff), f);
            }
        }
        float n = float(taps * taps);
        return ShadowSample(lit / n, through / n, c);
    }
    return r;
}

// past the shadow range everything is lit; the last min(10 %, 8 m) fade smoothly
float shadowRangeFade(float visibility, float viewDepth) {
    float fadeStart = max(SHADOW_RANGE - min(SHADOW_RANGE * 0.1, 8.0), 0.0);
    return mix(visibility, 1.0, smoothstep01(saturate((viewDepth - fadeStart) / (SHADOW_RANGE - fadeStart))));
}
#endif

// ------------------------------------------------------------------ cloud shadows
#ifndef SHADOWMAP_NO_CLOUDS
#include "/lib/clouds.glsl"

// cloud cells (lib/clouds.glsl) seen along the light from the middle of the cloud layer, box filtered over
// CLOUD_SHADOW_FILTER x 0.75 blocks (computed exactly from the cell overlap areas)
float cloudShadow(vec3 worldPos, vec3 lightDir, float filterScale) {
    #ifndef CLOUD_SHADOWS
        return 1.0;
    #else
        if (lightDir.y < 0.02 || !cloudGridKnown()) return 1.0;
        float layer = CLOUD_HEIGHT + CLOUD_THICKNESS * 0.5;
        if (worldPos.y > layer) return 1.0;
        vec2 hit = worldPos.xz + lightDir.xz * ((layer - worldPos.y) / lightDir.y);
        float halfWidth = float(clamp(int(CLOUD_SHADOW_FILTER * filterScale + 0.5), 1, 9)) * 0.75 * 0.5 / CLOUD_CELL;   // in cells
        vec2 centre = cloudGridPos(hit) / CLOUD_CELL;
        vec2 lo = centre - halfWidth, hi = centre + halfWidth;
        ivec2 first = ivec2(floor(lo));
        float covered = 0.0;
        for (int j = 0; j < 3; j++) for (int i = 0; i < 3; i++) {
            vec2 cell = vec2(first + ivec2(i, j));
            vec2 overlap = max(min(hi, cell + 1.0) - max(lo, cell), 0.0);
            float area = overlap.x * overlap.y;
            if (area > 0.0 && cloudCell(ivec2(cell))) covered += area;
        }
        float s = 1.0 - covered / (4.0 * halfWidth * halfWidth);
        return s < 0.999 ? min(max(s, 1.0 - CLOUD_SHADOW_STRENGTH), 1.0) : 1.0;
    #endif
}
#endif

#endif
