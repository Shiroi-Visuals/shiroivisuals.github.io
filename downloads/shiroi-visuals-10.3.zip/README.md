# Shiroi Visuals

Shaderpack PBR deferido para o Iris, feito para se parecer com o visual do Vibrant Visuals do Minecraft Bedrock.
Projeto independente: **não é afiliado, aprovado nem associado à Mojang Studios ou à Microsoft.** "Minecraft" e
"Vibrant Visuals" são marcas da Mojang / Microsoft.

## Requisitos

- Iris 1.11 ou mais novo (Minecraft 26.3). Também compila no Iris 1.8 (Minecraft 1.21.1) e no Vitrail (renderer
  Vulkan; lá a sombra usa uma cascata só).
- Placa com OpenGL 4.3 (compute shaders, imagens e SSBO).

## Instalação

Coloque o zip em `.minecraft/shaderpacks` e escolha "Shiroi Visuals" em Opções de vídeo → Pacotes de shader.
Não precisa de resource pack: materiais de blocos sem texture set vêm da "Tabela PBR por bloco" (menu Materiais).

## O que faz

- Iluminação PBR com sol, lua, céu e luz de bloco; sombras em cascata com filtro; sombra das nuvens.
- Céu com gradiente e halo que mudam ao longo do dia; névoa volumétrica com feixes de luz; neblina por bioma
  (pale garden), névoa branca na neve e na nevasca.
- Água com relevo animado, reflexos (sonda do céu e espaço de tela), cáusticas, extinção e névoa debaixo d'água;
  névoa dentro de powder snow e de lava.
- End com o flash (Iris 1.11) como luz direcional com sombra.
- Exposição automática e local, bloom, tonemapper e color grading (deserto e badlands mais quentes no pôr do sol).

## Créditos

- Ajuste ACES de Stephen Hill, como no BakingLab de MJP (licença MIT): veja `THIRD_PARTY_NOTICES.md`.
- As demais técnicas são publicações citadas no cabeçalho de cada arquivo (Karis, Lottes, Hable, Krystek, Jimenez,
  Wronski, Hillaire, Heeger & Bergen, Galerne et al., entre outros).
- Origem de cada parte do pack (código, dados de aparência, texturas): `PROVENIENCIA.md`.

---

# Shiroi Visuals (English)

Deferred PBR shaderpack for Iris, made to look like Minecraft Bedrock's Vibrant Visuals. Independent project: **not
affiliated with, endorsed by or associated with Mojang Studios or Microsoft.** "Minecraft" and "Vibrant Visuals" are
trademarks of Mojang / Microsoft. Requires Iris 1.11+ (Minecraft 26.3); also compiles on Iris 1.8 (1.21.1) and Vitrail.
Third-party code: `THIRD_PARTY_NOTICES.md`. Where each part comes from: `PROVENIENCIA.md` (Portuguese).
