# Shiroi Visuals Snapshot 26.3.7 — Iris Release

Stable Iris/OpenGL release for Minecraft 26.3. This edition retains the shader's original multi-cascade shadow atlas and the existing cloud, lighting, water, and post-processing effects.

## Compatibility

- Minecraft 26.3 with Fabric
- Iris 1.11.7 and Sodium 0.9.2 (validated release stack)
- OpenGL 4.3 GPU with compute shaders, image load/store, and shader storage buffer support

## Install

Place this ZIP in the instance's `.minecraft/shaderpacks` folder, then select **Shiroi Visuals Snapshot 26.3.7 — Iris Release** in Iris's Shader Packs menu. The shader-pack files are at the ZIP root.

For Vulkan through Vitrail, use the separate Vitrail Compatibility Release ZIP. Vitrail uses a renderer-specific single-cascade shadow path; see its README for the known difference.

## Minecraft 1.21.1 clouds

On Minecraft 1.21.1 with Iris and Sodium, vanilla clouds may not reach the shader pack's `gbuffers_clouds` pass. Follow [LEGACY_CLOUDS_1.21.1.md](LEGACY_CLOUDS_1.21.1.md) to apply the Sodium mixin setting to that instance. This configuration workaround is for the Iris + Sodium setup and changes the instance's Sodium config.

## Credits

See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) for the ACES attribution and license, and [PROVENIENCIA.md](PROVENIENCIA.md) for the pack's source and asset notes.
